        //a) 
        [ 4 9 6 9 ] [ 20 45 30 45 ]

        //b

        //line 1
        myQueue1 => empty
        myQueue2 => (head) 20 -> 45 -> 30 -> 45

        //line 2
        myQueue1 => empty
        myQueue2 => empty

        
